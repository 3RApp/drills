import { useParams } from 'react-router-dom';

const SecondPage = () => {
  const params = useParams();

  return (
    <div style={{ backgroundColor: '#DCDCDC', padding: '20px' }}>
      <h1 style={{ color: '#1B9CFC' }}>Вторая страница</h1>
      <h2>Данные из динамического сегмента</h2>
      <span style={{fontSize: "24px"}}>{params.first}</span>
    </div>
  );
};

export { SecondPage };