import { useParams } from 'react-router-dom';

const ThirdPage = () => {
  const params = useParams();

  return (
    <div style={{ backgroundColor: '#FCEA2B', padding: '20px' }}>
      <h1 style={{ color: '#ED4C67' }}>Третья страница</h1>
      <h2>Данные из динамических сегментов</h2>
      <span style={{fontSize: "24px"}}>Первый: {params.first}</span>
      <br /><span style={{fontSize: "24px"}}>Второй: {params.second}</span>
    </div>
  );
};

export { ThirdPage };