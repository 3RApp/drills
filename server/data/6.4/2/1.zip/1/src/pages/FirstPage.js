import { Link } from 'react-router-dom';

const FirstPage = () => {
  return (
    <div style={{ backgroundColor: '#EFEFEF', padding: '20px' }}>
      <h1 style={{ color: '#FFC300' }}>Первая страница</h1>
      <h2>Ссылки на страницы с одним динамическим сегментом в пути</h2>
      <nav>
        {
          new Array(3).fill(`/`).map((item, index) => {
            const dynamic = Math.floor(Math.random() * 100000);
            const path = `${item}${dynamic}`;

            return <div><Link key={index} to={path}>{path}</Link></div>
          })
        }
      </nav>
      <h2>Ссылки на страницы с двумя динамическими сегментами в пути</h2>
      <nav>
        {
          new Array(3).fill(`/`).map((item, index) => {
            const dynamicFirst = Math.floor(Math.random() * 100000);
            const dynamicSecond = Math.floor(Math.random() * 100000);
            const path = `${item}${dynamicFirst}/${dynamicSecond}`;

            return <div><Link key={index} to={path}>{path}</Link></div>
          })
        }
      </nav>      
    </div>
  );
};

export { FirstPage };