import { Outlet } from 'react-router-dom';

const FirstPage = () => {
  return (
    <div style={{ backgroundColor: '#EFEFEF', padding: '20px' }}>
      <h1 style={{ color: '#FFC300' }}>Первая страница</h1>
      <Outlet />
    </div>
  );
};

export { FirstPage };