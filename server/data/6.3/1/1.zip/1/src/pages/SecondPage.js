import { Outlet } from 'react-router-dom';

const SecondPage = () => {
  return (
    <div style={{ backgroundColor: '#DCDCDC', padding: '20px' }}>
      <h1 style={{ color: '#1B9CFC' }}>Вторая страница</h1>
      <Outlet />
    </div>
  );
};

export { SecondPage };