import { Outlet } from 'react-router-dom';

const ThirdPage = () => {
  return (
    <div style={{ backgroundColor: '#FCEA2B', padding: '20px' }}>
      <h1 style={{ color: '#ED4C67' }}>Третья страница</h1>
      <Outlet />
    </div>
  );
};

export { ThirdPage };