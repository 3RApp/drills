import { Outlet, Link } from "react-router-dom";

export const Layout = () => {
    return (<>
        <nav style={{ display: 'flex', gap: '1rem', alignItems: 'center', justifyContent: 'space-evenly', padding: '1rem' }}>
        <Link to="/">Главная</Link>
        <Link to="/second">Вторая страница</Link>
        <Link to="/third">Третья страница</Link>
        <Link to="/fourth">Четвёртая страница</Link>
        <Link to="/fifth">Пятая страница</Link>
        <Link to="/sixth">Шестая страница</Link>
        </nav>
       <section>
        <Outlet />
       </section>
    </>);
}