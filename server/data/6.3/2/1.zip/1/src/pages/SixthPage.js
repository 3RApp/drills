import { Outlet } from 'react-router-dom';

const SixthPage = () => {
  return (
    <div style={{ backgroundColor: '#FA8231', padding: '20px' }}>
      <h1 style={{ color: '#FB5607' }}>Шестая страница</h1>
      <Outlet />
    </div>
  );
};

export { SixthPage };