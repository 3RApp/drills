import { Outlet } from 'react-router-dom';

const FourthPage = () => {
  return (
    <div style={{ backgroundColor: '#ADD8E6', padding: '20px' }}>
      <h1 style={{ color: '#00BFFF' }}>Четвёртая страница</h1>
      <Outlet />
    </div>
  );
};

export { FourthPage };