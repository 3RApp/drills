import { Outlet } from 'react-router-dom';

const FifthPage = () => {
  return (
    <div style={{ backgroundColor: '#FFDD59', padding: '20px' }}>
      <h1 style={{ color: '#A3CB38' }}>Пятая страница</h1>
      <Outlet />
    </div>
  );
};

export { FifthPage };