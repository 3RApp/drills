import { Outlet, Link } from "react-router-dom";

export const Layout = () => {
    return (<>
        <nav style={{ display: 'flex', gap: '1rem', alignItems: 'center', justifyContent: 'space-evenly', padding: '1rem' }}>
        <Link to="/first">Главная</Link>
        <Link to="/first/second">Вторая страница</Link>
        <Link to="/first/third">Третья страница</Link>
        <Link to="/fourth">Четвёртая страница</Link>
        <Link to="/fourth/fifth">Пятая страница</Link>
        <Link to="/fourth/sixth">Шестая страница</Link>
        </nav>
       <section>
        <Outlet />
       </section>
    </>);
}