import React, { useState, useEffect, useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import SmallComponent from './SmallComponent';
import MediumComponent from './MediumComponent';
import DifferentComponent from './DifferentComponent';
import OtherTypeOfComponent from './OtherTypeOfComponent';
import AppContext from './AppContext';

const BigComponent = () => {

  const dataFromRedux = useSelector(state => state.data);
  const dispatch = useDispatch();

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const contextValue = useContext(AppContext);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch('/api/data');
        const result = await response.json();
        setData(result);
        setError(null);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setData([]);
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  if (error) {
    return (
      <div>
        <h1>Error: {error}</h1>
      </div>
    );
  }

  const handleMouseMove = event => {
    setMousePosition({
      x: event.clientX,
      y: event.clientY
    });
  };

  const handleMouseOver = () => {
    alert("Навели мышь!");
  };

  return (
    <>
      <h1 onMouseMove={handleMouseMove}>Big Component</h1>

      <SmallComponent 
        data={data.slice(0, 5)} 
        loading={loading} 
        handleMouseOver={handleMouseOver} 
      />

      <MediumComponent 
        data={data.slice(5, 10)}
        position={mousePosition}
      />

      <DifferentComponent 
        reduxData={dataFromRedux}
        dispatch={dispatch}
      />

      <OtherTypeOfComponent 
        contextValue={contextValue}
        position={mousePosition}
      />

      {!loading && (
        <ul>
          {data.map(item => (
            <li key={item.id}>{item.name}</li>
          ))}
        </ul>
      )}
    </>
  );
};

export default BigComponent;